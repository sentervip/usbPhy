//
//  AppController.h
//  Bulkloop_Cocoa_Apps
//
//  Created by USBHSP on 25/11/11.
//  Copyright 2011 Cypress Semiconductior. All rights reserved.
//

#import <Foundation/Foundation.h>
#include "libusb.h"
#define FirmwareDownload 0xA0

@interface AppController : NSObject {
@private
    
    libusb_device **devs;   //pointer to pointer of device, used to retrieve a list of devices
    int result;             //for return values
	ssize_t cnt;            //holds number of devices in list
    NSString *string;       //holds the text to be displayed in the textview
    NSString *string1;      //holds the specs of the Cypress device
    
    libusb_device_handle *dev_handle1;
    libusb_device *dev;
    struct libusb_config_descriptor *config;
    const struct libusb_interface *inter;
    const struct libusb_interface_descriptor *interdesc;
    const struct libusb_endpoint_descriptor *epdesc;
    
    IBOutlet NSButton *Infobutton_var;
    IBOutlet NSButton *Vndrbutton_var;
    IBOutlet NSButton *BulkXfer_var;
    
    IBOutlet NSTextView *actualtextview_var;
    IBOutlet NSTextField *Statuslabel;
    IBOutlet NSTextField *Data_bye;
    IBOutlet NSTextField *Num_of_bytes;
    IBOutlet NSComboBox *Endpointbox_var;
    
    IBOutlet NSTextField *Vndr_Reqcode_var;
    IBOutlet NSTextField *Vndr_Value_var;
    IBOutlet NSTextField *Vndr_Index_var;
    IBOutlet NSTextField *Vndr_Length_var;
    IBOutlet NSComboBox *Vndr_Dir_var;
}

- (NSString*) LibUsb_TransferData:(int) epaddr d:(enum libusb_endpoint_direction) dir;
- (NSString*) print;
- (void) Setup_EndpointBox;
- (IBAction)Infobutton:(id)sender;
- (IBAction)Bulk_Xfer:(id)sender;
- (IBAction)Clear:(id)sender;
- (IBAction)VndrReq_button:(id)sender;

@end
