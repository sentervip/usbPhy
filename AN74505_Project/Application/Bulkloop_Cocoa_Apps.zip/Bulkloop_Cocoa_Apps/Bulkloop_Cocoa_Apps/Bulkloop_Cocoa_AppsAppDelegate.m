//
//  Bulkloop_Cocoa_AppsAppDelegate.m
//  Bulkloop_Cocoa_Apps
//
//  Created by USBHSP on 25/11/11.
//  Copyright 2011 Cypress Semiconductior. All rights reserved.
//

#import "Bulkloop_Cocoa_AppsAppDelegate.h"

@implementation Bulkloop_Cocoa_AppsAppDelegate

@synthesize window;

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
    // Insert code here to initialize your application
}

@end
