//
//  AppController.m
//  Bulkloop_Cocoa_Apps
//
//  Created by USBHSP on 25/11/11.
//  Copyright 2011 Cypress Semiconductior. All rights reserved.
//

#import "AppController.h"
#include "libusb.h"

@implementation AppController

- (void) awakeFromNib{
    
    result = libusb_init(NULL);                 //initialize a library session
    if(result < 0)
        return;                                 //there was an error
    
    [Infobutton_var setEnabled:FALSE];          // keeping the various buttons in the GUI disables as default
    [BulkXfer_var setEnabled:FALSE];
    [Vndrbutton_var setEnabled:FALSE];
    
    string1 = [self print];                     //calls method "print" as to assign the specs of Cypress device (VID = 0x04B4) into string1
    string = @"";
    [Vndr_Dir_var selectItemAtIndex:0];
    
}

- (void) applicationWillTerminate{
    
    libusb_free_device_list(devs, 1);                     //free the list, unref the devices in it
	libusb_exit(NULL);                                    //close the session
    
}

/*
  Method "print" returns the specs of the Cypress device (VID = 0x04B4), if found
 */

- (NSString*) print                                 
{
    
	int i,j,k,l= 0;
    NSString *str;
    
    cnt = libusb_get_device_list(NULL, &devs);                           //gets the list of devices
    [Statuslabel setStringValue:@"Cypress device not found"];
    str = [NSString stringWithFormat:@"device info \n"];
   
    
    while((dev = devs[l++]) != NULL)
    {
		struct libusb_device_descriptor desc;
		int r1 = libusb_get_device_descriptor(dev, &desc);              //gets the device descriptor of the USB device found
		if (r1 < 0) 
        {
            str = [str stringByAppendingString:@"failed to get descriptor"];
			return str;
		}
        
        if(desc.idVendor == 0x04B4)                                     //checks if device found is Cypress
        {   [Statuslabel setStringValue:@"Cypress device found"];       //Status label updated
            [Infobutton_var setEnabled:TRUE];                           //Info button enabled, if Cypress device found.
            dev_handle1 = libusb_open_device_with_vid_pid(NULL, 0x04B4, desc.idProduct);  //opens the Cypress device. Gets the device handle for all future operations.
            
            str = [str stringByAppendingFormat:@"vid = %04x, pid = %04x\n bus num =  %d, dev address = %d", desc.idVendor, desc.idProduct,libusb_get_bus_number(dev), libusb_get_device_address(dev)];
            str = [str stringByAppendingFormat:@"num of configs: %d \n", desc.bNumConfigurations];
            
            libusb_get_config_descriptor(dev, 0, &config);              //gets the configuration descriptor of the Cypress device found.
            str = [str stringByAppendingFormat:@"num of interfaces: %d\n\n", config->bNumInterfaces];
            
            
            for(i=0;i<(int)config->bNumInterfaces;i++)
            {   
                inter = &config->interface[i];
                str = [str stringByAppendingFormat:@"Number of alternate settings   %d\n\n",inter->num_altsetting];
                for(j=0;j<inter->num_altsetting;j++)
                {
                    interdesc = &inter->altsetting[j];                  //gets the interface descriptor of the selected interface of Cypress device.
                    str = [str stringByAppendingFormat:@"interface Number   %d\n",(int)interdesc->bInterfaceNumber];
                    str = [str stringByAppendingFormat:@"Alternate Setting   %d\n",(int) interdesc->bAlternateSetting];
                    str = [str stringByAppendingFormat:@"Number of Endpoints   %d\n",(int) interdesc->bNumEndpoints];
                    
                    
                    for(k=0;k<(int) interdesc->bNumEndpoints;k++)
                    {
                        epdesc = &interdesc->endpoint[k];               //gets the endpoint descriptor of the selected endpoint.    
                        str = [str stringByAppendingFormat:@"EP Address %x  ",(int) epdesc->bEndpointAddress];
                        
                        switch((epdesc->bmAttributes)&0x03)
                        {
                                
                            case 0: 
                                str = [str stringByAppendingFormat:@"BULK IN Endpoint  "];
                                break;
                                
                            case 1: 
                                if((epdesc->bEndpointAddress) & 0x80)
                                    str = [str stringByAppendingFormat:@"Isochronous IN Endpoint  "];
                                else
                                    str = [str stringByAppendingFormat:@"Isochronous OUT Endpoint  "];
                                break;
                                
                            case 2: 
                                if((epdesc->bEndpointAddress) & 0x80)
                                    str = [str stringByAppendingFormat:@"Bulk IN Endpoint  "];
                                else
                                    str = [str stringByAppendingFormat:@"Bulk OUT Endpoint  "];
                                break;
                                
                            case 3: 
                                if((epdesc->bEndpointAddress) & 0x80)
                                    str = [str stringByAppendingFormat:@"Interrupt IN Endpoint  "];
                                else
                                    str = [str stringByAppendingFormat:@"Interuppt OUT Endpoint  "];
                                break;
                                
                        }
                        
                        str = [str stringByAppendingFormat:@"\n"];
                        
                    }
                    
                }
                
            }
            
            if(desc.idProduct == 0x1004)                            //checks if the Cypress device found is same as Bulkloop device
            {    
                [BulkXfer_var setEnabled:TRUE];                     //Bulk Transfers button and Vendor Request button enabled only if Bulkloop device found
                [Vndrbutton_var setEnabled:TRUE];
                [self Setup_EndpointBox];                          //Calls method "Setup_EndpointBox" as to set up combobox(EndPointBox) with the endpoints available in the bulkloop device
                
            }
            
            libusb_free_config_descriptor(config);                 //Frees the configuration descriptor
        }
        
        
	}
    
    str = [str stringByAppendingFormat:@"\n"];                     //str contains the spec of the Cypress device, if found.
    return str;
    
}   

/*
   Method " LibUsb_TransferData: d:" . Intiates bulk data transfers from/to the endpoint which is passed as parameter.
 
 */

- (NSString*) LibUsb_TransferData:(int) epaddr d:(enum libusb_endpoint_direction) dir
{
    
    libusb_device_handle *dev_handle;
    int actual,i,r,s;
    
    unsigned char data1[1024];
    int vid = 0x04B4;
    int pid = 0x1004;
    int len;
    NSString *str = @"";
    
    
    dev_handle = libusb_open_device_with_vid_pid(NULL, vid, pid);       //checks for the Bulkloop device and opens the Bulkloope device (VID = 0x04B4/ PID = 0x1004) if found. 
    
    if(dev_handle == NULL)
        str = [str stringByAppendingFormat:@"Cannot open device\n"];
    
    
    r = libusb_claim_interface(dev_handle, 0);                          //Claim an interface on a given device handle.
    if(r < 0) 
    {
        str = [str stringByAppendingFormat:@"Cannot Claim Interface\n\n"];
        return str;
    }
    
    
    len = [[Num_of_bytes stringValue] intValue];
    if (dir == LIBUSB_ENDPOINT_OUT)
    {
        for(i=0;i < len;i++)
        {
            data1[i] = strtol((char *) [[Data_bye stringValue] UTF8String], NULL, 16);                      //to convert hex string into binary
        }
    }
    
    if(dir)
        epaddr = epaddr | 0x80;
    
    s = libusb_bulk_transfer(dev_handle, epaddr, data1,len, &actual, 100);                                  //Perform a USB bulk transfer
    
    
    if(s == 0 && actual == len)                                                                             //we transferred the  bytes successfully
    {
        if(dir == LIBUSB_ENDPOINT_OUT)
            
            str = [str stringByAppendingFormat:@"Writing to Endpoint %d Successful!\n",epaddr];
        else
            str = [str stringByAppendingFormat:@"Reading from Endpoint %d Successful!\n",epaddr ^ 0x80];
        
        str = [str stringByAppendingFormat:@"Total Bytes Transferred: %d\n", actual];
        
        str = [str stringByAppendingFormat:@"Transferred Data:"];
        
        for(i=0;i<len;i++)
        {
            if(!(i%16))
                str = [str stringByAppendingFormat:@"\n %04x   ", i];
            
            str = [str stringByAppendingFormat:@"%02x  ",data1[i]];
        }
        
        str = [str stringByAppendingFormat:@"\n\n"];
        
    }
    else
    {
        if(dir == LIBUSB_ENDPOINT_OUT)
            str = [str stringByAppendingFormat:@"Writing to Endpoint %d failed!\n\n",epaddr];
        else
            str = [str stringByAppendingFormat:@"Reading from Endpoint %d failed!\n\n",epaddr ^ 0x80];
    }
    
    r = libusb_release_interface(dev_handle, 0);                                                        //release the claimed interface
    
    if(r!=0) 
    {    str = [str stringByAppendingFormat:@"Cannot Release Interface\n\n"];
        return str;
        
    }
    
    
    
    libusb_close(dev_handle);                                                                           //close the device we opened
    return str;                                                                                         // "str" contains the string to represent result of the transfer and data transferred 
    
}

/*
    IBAction linked with "Show Cypress Device Info" button. Appends the string1 to the textview display that contains the specs of the Cypress device found, which is computed in the "print" method. 
 */

- (IBAction)Infobutton:(id)sender{
    
    if(dev_handle1 != NULL)
    {   
        
        string = [string stringByAppendingFormat:string1];
        [actualtextview_var setString:string]; 
        
    }

}

/*
 IBAction linked with Bulk Transfers button: "Bulk_Xfer:". Depending on the endpoint selected from the combobox, "EndpointBox", calls LibUsb_TransferData method, with appropriate parameters.
 
 */

- (IBAction)Bulk_Xfer:(id)sender {
    
    
    switch ([Endpointbox_var indexOfSelectedItem]) {
            
        case 0:
            string = [string stringByAppendingFormat:[self LibUsb_TransferData:2 d:LIBUSB_ENDPOINT_OUT]];            
            break;
        case 1:
            string = [string stringByAppendingFormat:[self LibUsb_TransferData:4 d:LIBUSB_ENDPOINT_OUT]];            
            break;
        case 2:
            string = [string stringByAppendingFormat:[ self LibUsb_TransferData:6 d:LIBUSB_ENDPOINT_IN]];
            break;
        case 3:
            string = [string stringByAppendingFormat:[ self LibUsb_TransferData:8 d:LIBUSB_ENDPOINT_IN]];
            break;
        default:
            break;
    }
    
    [actualtextview_var setString:string];                                                      // update textview with result of transfer, data bytes transferred
    
}

/*
 IBAction linked with Clear button: "Clear:". Clears the "textview" text.
 */


- (IBAction)Clear:(id)sender {
    string = @"";
    [actualtextview_var setString:string]; 
    
}

/*
  IBAction linked with Vendor Requests button: "VndrReq_button:". Initiates the Vendor command to the device, with appropriate parameters as entered by the user.
 */

- (IBAction)VndrReq_button:(id)sender {
    
    uint8_t 	bmRequestType;
    uint8_t 	bRequest;
    uint16_t 	wValue;
    uint16_t 	wIndex;
    unsigned char  	ret_data[64];
    uint16_t 	wLength;
    uint8_t dir;
    int result1;
    
    bRequest = strtol((char *) [[Vndr_Reqcode_var stringValue] UTF8String], NULL, 16);
    wValue = strtol((char *) [[Vndr_Value_var stringValue] UTF8String], NULL, 16);
    wIndex = strtol((char *) [[Vndr_Index_var stringValue] UTF8String], NULL, 16);
    wLength = strtol((char *) [[Vndr_Length_var stringValue] UTF8String], NULL, 10);
    switch ([Vndr_Dir_var indexOfSelectedItem]) {
        case 0:
            dir = 0x00;
            break;
        case 1:
            dir = 0x80;
            break;
        default:
            break;
    }
    
    bmRequestType = dir | LIBUSB_REQUEST_TYPE_VENDOR;
    
    result1 = libusb_control_transfer(dev_handle1, bmRequestType, bRequest, wValue, wIndex, ret_data, wLength, 1000);       //Perform a USB control transfer
    if(result1 >= 0)
        string = [string stringByAppendingFormat:@"\n Vendor Command Successful \n %02x \n ", ret_data[0]];
    else
        string = [string stringByAppendingFormat:@"Vendor command failed \n"];
    [actualtextview_var setString:string];                                                          //displays the result of the Vendor command.
    
}


/*
 Method "Setup_EndpointBox" - sets up the combobox "EndpointBox" with endpoints available in the bulkloop device
 */

- (void) Setup_EndpointBox
{
    
	int k = 0;
    NSString *str = @"";
    
    for(k=0;k<(int) interdesc->bNumEndpoints;k++)
    {
        epdesc = &interdesc->endpoint[k];
        str = [str stringByAppendingFormat:@"EP Address %02x  ",(int) epdesc->bEndpointAddress];
        
        switch((epdesc->bmAttributes)&0x03)
        {
                
            case 0: 
                str = [str stringByAppendingFormat:@"BULK IN Endpoint  "];
                break;
                
            case 1: 
                if((epdesc->bEndpointAddress) & 0x80)
                    str = [str stringByAppendingFormat:@"Isochronous IN Endpoint  "];
                else
                    str = [str stringByAppendingFormat:@"Isochronous OUT Endpoint  "];
                break;
                
            case 2: 
                if((epdesc->bEndpointAddress) & 0x80)
                    str = [str stringByAppendingFormat:@"Bulk IN Endpoint  "];
                else
                    str = [str stringByAppendingFormat:@"Bulk OUT Endpoint  "];
                break;
                
            case 3: 
                if((epdesc->bEndpointAddress) & 0x80)
                    str = [str stringByAppendingFormat:@"Interrupt IN Endpoint  "];
                else
                    str = [str stringByAppendingFormat:@"Interuppt OUT Endpoint  "];
                break;
                
        }
        [Endpointbox_var addItemWithObjectValue:str];
        
        str = @"";
        
    }
    
    [Endpointbox_var selectItemAtIndex:0];
    
    
}



@end
